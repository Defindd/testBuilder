@echo off
setlocal

set "ROOT=%~dp0"
set "TEMP=%ROOT%data\temp"
set "TMP=%ROOT%data\temp"
set "DOTNET_BUNDLE_EXTRACT_BASE_DIR=%ROOT%data\bundle"

if not exist "%TEMP%" mkdir "%TEMP%"
if not exist "%DOTNET_BUNDLE_EXTRACT_BASE_DIR%" mkdir "%DOTNET_BUNDLE_EXTRACT_BASE_DIR%"

pushd "%ROOT%"
start "" "%ROOT%TestBuilder.UI.exe"
popd

endlocal
